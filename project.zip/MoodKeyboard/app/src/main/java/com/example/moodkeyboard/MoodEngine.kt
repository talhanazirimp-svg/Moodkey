package com.example.moodkeyboard

enum class Mood(val label: String, val emoji: String, val words: Set<String>, val emojis: List<String>) {
    HAPPY("Happy", "😄", setOf("happy", "glad", "great", "awesome", "amazing", "yay", "lol", "haha", "nice", "good", "fun", "best", "win", "won", "khush", "mast"), listOf("😄", "😂", "😊", "😁", "🥳")),
    SAD("Sad", "😢", setOf("sad", "cry", "crying", "miss", "lonely", "alone", "hurt", "sorry", "tired", "bad", "worst", "depressed", "udaas"), listOf("😢", "😭", "💔", "😞", "🥺")),
    ROMANTIC("Romantic", "🥰", setOf("love", "loved", "baby", "babe", "darling", "kiss", "date", "cute", "beautiful", "handsome", "crush", "heart", "pyaar", "jaan"), listOf("😍", "🥰", "😘", "❤️", "💕")),
    ANGRY("Angry", "😡", setOf("angry", "hate", "mad", "annoyed", "furious", "stupid", "idiot", "ugh", "wtf", "pissed", "gussa"), listOf("😡", "🤬", "😤")),
    EXCITED("Excited", "🤩", setOf("party", "excited", "omg", "wow", "trip", "tonight", "weekend", "birthday", "celebrate", "dance"), listOf("🎉", "🤩", "🔥")),
    STRESSED("Stressed", "😰", setOf("stress", "stressed", "exam", "deadline", "anxious", "worried", "nervous", "panic", "pressure", "busy", "overwhelmed", "tension"), listOf("😰", "😩", "😫", "😬")),
    CHILL("Chill", "😌", setOf("chill", "relax", "relaxing", "coffee", "sunday", "rain", "lazy", "sleep", "home", "movie", "netflix", "cozy"), listOf("😌", "☕", "😴"))
}

object MoodEngine {
    private val negations = setOf("not", "no", "never", "dont", "don't", "isnt", "isn't", "cant", "can't", "nahi")

    /** On-device only. Returns the most likely mood of the text, or null. */
    fun detect(text: String): Mood? {
        val lower = text.lowercase()
        val scores = mutableMapOf<Mood, Double>()
        fun add(m: Mood, v: Double) { scores[m] = (scores[m] ?: 0.0) + v }
        val tokens = lower.split(Regex("[^\\p{L}']+")).filter { it.isNotEmpty() }
        tokens.forEachIndexed { i, t ->
            val neg = i > 0 && tokens[i - 1] in negations
            Mood.values().forEach { m ->
                if (t in m.words) when {
                    neg && m == Mood.HAPPY -> add(Mood.SAD, 1.0)
                    neg && m == Mood.SAD -> add(Mood.CHILL, 1.0)
                    else -> add(m, 1.0)
                }
            }
        }
        Mood.values().forEach { m -> m.emojis.forEach { e -> if (lower.contains(e)) add(m, 1.0) } }
        if (Regex("!{2,}").containsMatchIn(text)) add(Mood.EXCITED, 0.5)
        if (text.contains("...")) add(Mood.SAD, 0.3)
        if (Regex("[A-Z]{4,}").containsMatchIn(text) && text == text.uppercase()) add(Mood.ANGRY, 1.0)
        return scores.maxByOrNull { it.value }?.takeIf { it.value > 0 }?.key
    }
}
