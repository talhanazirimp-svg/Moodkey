package com.example.moodkeyboard

import android.content.Intent
import android.graphics.Color
import android.inputmethodservice.InputMethodService
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.text.InputType
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.Button
import android.widget.HorizontalScrollView
import android.widget.ScrollView
import android.widget.LinearLayout
import android.widget.TextView
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

/**
 * Keyboard that judges the vibe of what you type (on-device), picks a trending Reels song for it,
 * and plays a 30-second preview in the background. Only the song name is sent online, never your text.
 */
class MoodKeyboardService : InputMethodService() {

    private val main = Handler(Looper.getMainLooper())
    private var player: MediaPlayer? = null
    private var playToken = 0
    private var pending: Runnable? = null

    private var shift = false
    private var secure = false
    private var auto = true
    private var mood: Mood? = null
    private var songIdx = 0
    private var song: Song? = null
    private var link: String? = null
    private val buffer = StringBuilder()   // recent typed words, memory only, never saved

    private lateinit var strip: TextView
    private lateinit var playBtn: Button
    private lateinit var autoBtn: Button
    private val letterKeys = mutableListOf<Button>()
    private lateinit var emojiBar: LinearLayout
    private lateinit var keysArea: LinearLayout
    private lateinit var emojiPanel: ScrollView
    private lateinit var emojiToggle: Button

    private val quickEmojis = listOf("😂", "❤️", "😍", "😭", "🔥", "👍", "🙏", "😊", "🥰", "😘")
    private val moodEmojis = mapOf(
        Mood.HAPPY to listOf("😄", "😂", "🥳", "😁", "😊", "🙌"),
        Mood.SAD to listOf("😢", "😭", "💔", "🥺", "😞", "🫂"),
        Mood.ROMANTIC to listOf("😍", "🥰", "😘", "❤️", "💕", "😏"),
        Mood.ANGRY to listOf("😡", "🤬", "😤", "💢", "🙄", "😒"),
        Mood.EXCITED to listOf("🎉", "🤩", "🔥", "🥳", "🚀", "💃"),
        Mood.STRESSED to listOf("😰", "😩", "😫", "😬", "🙏", "☕"),
        Mood.CHILL to listOf("😌", "☕", "😴", "🌧️", "🎧", "🍿")
    )
    private val allEmojis = ("😀😃😄😁😆😅😂🤣😊😇🙂😉😍🥰😘😗😋😛😜🤪😎🤩🥳😏😒😞😔😟😕🙁😣😖😫😩🥺😢😭😤😠😡🤬🤯😳🥵🥶😱😰😥😓🤗🤔🤭🤫🙄😬😴🤤😷🤒" +
        "👍👎👏🙌🙏💪👋🤝✌️🤞👌🤙❤️🧡💛💚💙💜🖤💔💕💖💯🔥✨🎉🎊🎶🎵🎧☕🍕🍔🍟🍿🎂🌹🌧️☀️🌙⭐🚀💃🕺").toList()
        .let { chars ->   // keep multi-codepoint emojis intact
            val out = mutableListOf<String>()
            var i = 0
            val str = chars.joinToString("")
            while (i < str.length) {
                val cp = str.codePointAt(i)
                var len = Character.charCount(cp)
                while (i + len < str.length && (str[i + len] == '\uFE0F' || str[i + len] == '\u200D')) len++
                out.add(str.substring(i, i + len)); i += len
            }
            out
        }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate() {
        super.onCreate()
        Trending.loadCached(this)
        Trending.autoUpdateIfStale(this)   // quietly checks for a newer trending list once a day
    }

    override fun onCreateInputView(): View {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.parseColor("#ECEFF1"))
            setPadding(dp(3), dp(3), dp(3), dp(3))
        }

        strip = TextView(this).apply {
            text = "🎧 Start typing, a trending song will follow your vibe"
            textSize = 14f
            setTextColor(Color.BLACK)
            setBackgroundColor(Color.WHITE)
            setPadding(dp(12), dp(10), dp(12), dp(10))
            setOnLongClickListener { openYouTube(); true }   // long-press = open in YouTube
        }
        root.addView(strip, LinearLayout.LayoutParams(-1, -2))

        val controls = row()
        playBtn = key("▶") { togglePlay() }
        autoBtn = key("Auto ON") { auto = !auto; autoBtn.text = if (auto) "Auto ON" else "Auto OFF" }
        controls.addView(playBtn, weight(1f))
        controls.addView(key("⏭") { songIdx++; choose(true) }, weight(1f))
        controls.addView(autoBtn, weight(1.6f))
        controls.addView(key("📤 Send") { sendClip() }, weight(1.6f))
        root.addView(controls)

        emojiBar = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        root.addView(HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false; addView(emojiBar) })
        fillEmojiBar(quickEmojis)

        keysArea = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        emojiPanel = ScrollView(this).apply { visibility = View.GONE }
        val grid = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        allEmojis.chunked(8).forEach { chunk ->
            val r = row()
            chunk.forEach { e -> r.addView(key(e) { type(e) }.apply { textSize = 22f }, weight(1f)) }
            repeat(8 - chunk.size) { r.addView(View(this), weight(1f)) }
            grid.addView(r)
        }
        emojiPanel.addView(grid)
        root.addView(emojiPanel, LinearLayout.LayoutParams(-1, dp(150)))

        listOf("qwertyuiop", "asdfghjkl", "zxcvbnm").forEachIndexed { idx, letters ->
            val r = row()
            if (idx == 2) r.addView(key("⇧") { shift = !shift; refreshCase() }, weight(1.5f))
            letters.forEach { c ->
                val b = key(c.toString()) {
                    type(if (shift) c.uppercaseChar().toString() else c.toString())
                    if (shift) { shift = false; refreshCase() }
                }
                letterKeys.add(b); r.addView(b, weight(1f))
            }
            if (idx == 2) r.addView(key("⌫") {
                sendDownUpKeyEvents(KeyEvent.KEYCODE_DEL)
                if (buffer.isNotEmpty()) buffer.deleteCharAt(buffer.length - 1)
                scheduleAnalyze()
            }, weight(1.5f))
            keysArea.addView(r)
        }
        root.addView(keysArea)

        val bottom = row()
        bottom.addView(key("🌐") {
            (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).showInputMethodPicker()
        }, weight(1.2f))
        emojiToggle = key("😊") {
            val show = emojiPanel.visibility != View.VISIBLE
            emojiPanel.visibility = if (show) View.VISIBLE else View.GONE
            keysArea.visibility = if (show) View.GONE else View.VISIBLE
            emojiToggle.text = if (show) "ABC" else "😊"
        }
        bottom.addView(emojiToggle, weight(1.2f))
        bottom.addView(key(",") { type(",") }, weight(1f))
        bottom.addView(key("space") { type(" ") }, weight(5f))
        bottom.addView(key(".") { type(".") }, weight(1f))
        bottom.addView(key("↵") {
            sendDownUpKeyEvents(KeyEvent.KEYCODE_ENTER)
            if (!secure) buffer.append(" ")
        }, weight(1.5f))
        root.addView(bottom)
        return root
    }

    override fun onStartInputView(info: EditorInfo?, restarting: Boolean) {
        super.onStartInputView(info, restarting)
        val t = info?.inputType ?: 0
        val cls = t and InputType.TYPE_MASK_CLASS
        val v = t and InputType.TYPE_MASK_VARIATION
        secure = (cls == InputType.TYPE_CLASS_TEXT && v in setOf(
            InputType.TYPE_TEXT_VARIATION_PASSWORD,
            InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD,
            InputType.TYPE_TEXT_VARIATION_WEB_PASSWORD
        )) || (cls == InputType.TYPE_CLASS_NUMBER && v == InputType.TYPE_NUMBER_VARIATION_PASSWORD)
        if (secure) {
            buffer.clear(); stopPlayer()
            strip.text = "🔒 Off in password fields"
        }
    }

    override fun onFinishInputView(finishingInput: Boolean) {
        super.onFinishInputView(finishingInput)
        stopPlayer()
    }

    override fun onDestroy() { stopPlayer(); super.onDestroy() }

    // ---- typing + AI judging -----------------------------------------------
    private fun type(s: String) {
        currentInputConnection?.commitText(s, 1)
        if (secure) return
        buffer.append(s)
        if (buffer.length > 400) buffer.delete(0, buffer.length - 400)
        scheduleAnalyze(if (s.any { it.code > 0x2000 }) 150L else 1200L)   // emojis react almost instantly
    }

    /** Waits ~1.2 s after you stop typing so the song doesn't flip on every key. */
    private fun scheduleAnalyze(delayMs: Long = 1200) {
        pending?.let { main.removeCallbacks(it) }
        pending = Runnable { analyze() }.also { main.postDelayed(it, delayMs) }
    }

    private fun analyze() {
        if (secure) return
        val fieldText = currentInputConnection?.getTextBeforeCursor(200, 0)?.toString().orEmpty()
        val m = MoodEngine.detect(buffer.toString().takeLast(250) + " " + fieldText) ?: return
        if (m != mood) { mood = m; songIdx = 0; choose(auto) }
    }

    private fun choose(play: Boolean) {
        val list = Trending.forMood(mood)
        val s = list[songIdx % list.size]
        song = s; link = null
        fillEmojiBar(moodEmojis[mood] ?: quickEmojis)
        strip.text = "${mood?.emoji ?: "🔥"} ${mood?.label ?: "Trending"}  •  ${s.title} – ${s.artist}"
        if (play) fetchAndPlay(s)
    }

    // ---- music (30 s previews from the iTunes Search API, no login or key) --
    private fun fetchAndPlay(s: Song) {
        val token = ++playToken
        stopPlayer()
        Thread {
            try {
                val term = URLEncoder.encode("${s.title} ${s.artist}", "UTF-8")
                val conn = URL("https://itunes.apple.com/search?media=music&entity=song&limit=1&term=$term")
                    .openConnection() as HttpURLConnection
                conn.connectTimeout = 5000; conn.readTimeout = 5000
                val results = JSONObject(conn.inputStream.bufferedReader().readText()).getJSONArray("results")
                if (results.length() == 0) { main.post { if (token == playToken) strip.append("  (not found)") }; return@Thread }
                val o = results.getJSONObject(0)
                val preview = o.optString("previewUrl")
                val view = o.optString("trackViewUrl")
                main.post { if (token == playToken) { link = view; startPlayer(preview) } }
            } catch (e: Exception) {
                main.post { if (token == playToken) strip.append("  (offline)") }
            }
        }.start()
    }

    private fun startPlayer(url: String) {
        stopPlayer()
        player = MediaPlayer().apply {
            setAudioAttributes(AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_MEDIA)
                .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build())
            setDataSource(url)
            setOnPreparedListener { it.start(); playBtn.text = "⏸" }
            setOnCompletionListener { playBtn.text = "▶" }
            prepareAsync()
        }
    }

    private fun stopPlayer() {
        player?.release(); player = null
        if (::playBtn.isInitialized) playBtn.text = "▶"
    }

    private fun togglePlay() {
        val p = player
        when {
            p == null -> song?.let { fetchAndPlay(it) } ?: choose(true)
            p.isPlaying -> { p.pause(); playBtn.text = "▶" }
            else -> { p.start(); playBtn.text = "⏸" }
        }
    }

    /** Inserts the song name + link into your message. The other person taps it to hear the song. */
    private fun sendClip() {
        val s = song ?: return
        val l = link ?: return
        currentInputConnection?.commitText("🎵 ${s.title} – ${s.artist} $l ", 1)
    }

    private fun openYouTube() {
        val s = song ?: return
        val q = Uri.encode("${s.title} ${s.artist}")
        startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/results?search_query=$q"))
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    private fun fillEmojiBar(list: List<String>) {
        emojiBar.removeAllViews()
        list.forEach { e ->
            emojiBar.addView(key(e) { type(e) }.apply { textSize = 20f },
                LinearLayout.LayoutParams(dp(52), dp(44)).apply { setMargins(dp(2), dp(2), dp(2), dp(2)) })
        }
    }

    // ---- view helpers -------------------------------------------------------
    private fun refreshCase() = letterKeys.forEach {
        it.text = if (shift) it.text.toString().uppercase() else it.text.toString().lowercase()
    }

    private fun row() = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }

    private fun weight(w: Float) = LinearLayout.LayoutParams(0, dp(48), w).apply { setMargins(dp(2), dp(2), dp(2), dp(2)) }

    private fun key(label: String, onTap: () -> Unit) = Button(this).apply {
        text = label
        isAllCaps = false
        setPadding(0, 0, 0, 0)
        setOnClickListener { onTap() }
    }
}
