package com.example.moodkeyboard

import android.content.Context
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

data class Song(val title: String, val artist: String)

/**
 * Trending Reels songs. Works like a keyboard language pack:
 * built-in list first, then a newer list downloaded from TRENDING_URL replaces it and is cached on the phone.
 */
object Trending {
    /** Put trending.json in your own GitHub repo (or any web host) and paste its raw link here. */
    const val TRENDING_URL = "https://raw.githubusercontent.com/YOUR_NAME/YOUR_REPO/main/trending.json"

    private val patientZero = Song("Patient Zero", "Taylor Swift")
    private val nicoleKidman = Song("Nicole Kidman", "ADÉLA")
    private val pure = Song("Pure", "Sienna Spiro")
    private val upsideDown = Song("Upside Down", "Diana Ross")
    private val helloOctober = Song("Hello October", "Sugar Lime Blue")
    private val beOk = Song("Be OK", "Ingrid Michaelson")
    private val ramalama = Song("Ramalama (Bang Bang)", "Róisín Murphy")
    private val funkytown = Song("Funkytown", "Lipps Inc.")
    private val iKnewIt = Song("I Knew It, I Knew You", "Taylor Swift")
    private val stopWedding = Song("Stop the Wedding", "Ashe")
    private val autumn = Song("Autumn Colors", "LuLuMusic")
    private val lessThanLover = Song("Less Than a Lover", "JENNIE")

    var version = "built-in (Oct 7, 2026)"; private set
    var top: List<Song> = listOf(patientZero, nicoleKidman, pure, upsideDown, helloOctober, beOk, ramalama, funkytown, iKnewIt); private set
    private var byMood: Map<Mood, List<Song>> = mapOf(
        Mood.HAPPY to listOf(upsideDown, funkytown, nicoleKidman),
        Mood.SAD to listOf(beOk, stopWedding, iKnewIt),
        Mood.ROMANTIC to listOf(pure, lessThanLover, iKnewIt),
        Mood.ANGRY to listOf(stopWedding, nicoleKidman, ramalama),
        Mood.EXCITED to listOf(patientZero, ramalama, funkytown),
        Mood.STRESSED to listOf(beOk, autumn, helloOctober),
        Mood.CHILL to listOf(helloOctober, autumn, pure)
    )

    fun forMood(m: Mood?): List<Song> = if (m == null) top else (byMood[m]?.takeIf { it.isNotEmpty() } ?: top)

    private fun file(ctx: Context) = File(ctx.filesDir, "trending.json")

    /** Call once when the keyboard starts: loads the last downloaded list, if any. */
    fun loadCached(ctx: Context) {
        val f = file(ctx)
        if (f.exists()) parse(f.readText())
    }

    /** Downloads the newest list. Runs on its own thread; onDone gets a short status message. */
    fun update(ctx: Context, onDone: (String) -> Unit) {
        Thread {
            val msg = try {
                val c = URL(TRENDING_URL).openConnection() as HttpURLConnection
                c.connectTimeout = 6000; c.readTimeout = 6000
                val text = c.inputStream.bufferedReader().readText()
                if (parse(text)) {
                    file(ctx).writeText(text)
                    ctx.getSharedPreferences("trend", Context.MODE_PRIVATE).edit()
                        .putLong("last", System.currentTimeMillis()).apply()
                    "Trending updated: $version"
                } else "Bad trending file"
            } catch (e: Exception) { "Couldn't update (offline or URL not set)" }
            onDone(msg)
        }.start()
    }

    /** Checks at most once a day, silently. */
    fun autoUpdateIfStale(ctx: Context) {
        val last = ctx.getSharedPreferences("trend", Context.MODE_PRIVATE).getLong("last", 0)
        if (System.currentTimeMillis() - last > 24L * 3600 * 1000) update(ctx) {}
    }

    private fun parse(json: String): Boolean = try {
        val root = JSONObject(json)
        fun songs(a: org.json.JSONArray) = (0 until a.length()).map {
            val o = a.getJSONObject(it); Song(o.getString("title"), o.getString("artist"))
        }
        val newTop = songs(root.getJSONArray("top"))
        val moods = root.getJSONObject("moods")
        val newMap = Mood.values().associateWith { m ->
            if (moods.has(m.name)) songs(moods.getJSONArray(m.name)) else emptyList()
        }
        if (newTop.isEmpty()) false else {
            version = root.optString("version", "downloaded")
            top = newTop; byMood = newMap; true
        }
    } catch (e: Exception) { false }
}
