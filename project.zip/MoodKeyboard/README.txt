SETUP (Android Studio)
1. New Project > "Empty Views Activity", Kotlin, package: com.example.moodkeyboard, min SDK 24.
2. Copy into the project (replace if they exist):
   - AndroidManifest.xml  -> app/src/main/
   - res/xml/method.xml   -> app/src/main/res/xml/
   - MoodEngine.kt, Trending.kt, MoodKeyboardService.kt, MainActivity.kt -> app/src/main/java/com/example/moodkeyboard/
3. Run on your phone. In the app: "1. Enable keyboard", turn it on, "2. Switch".
4. In WhatsApp pick MoodKeyboard (globe key) and type.

TRENDING UPDATES (like a language pack)
1. Create a free GitHub repo, upload trending.json (from this zip).
2. Open the file on GitHub > Raw > copy the link.
3. Paste that link into TRENDING_URL in Trending.kt, rebuild once.
4. Every week replace the contents of trending.json on GitHub (works from a phone).
   The keyboard checks once a day and downloads it automatically.
   The app's "3. Download latest trending" button updates it instantly.

EMOJIS
- Row under the buttons: emojis that match your current vibe (tap to insert).
- 😊 key: full emoji panel. ABC goes back to letters.
- Tapping an emoji changes the song within a fraction of a second.

BUTTONS
Play/pause, next song, Auto on/off, Send (song name + link into your message). Long-press the top strip to open in YouTube.
